TEST VIEW
<br>
Valore a: {{ $a ?? null }} <br>
Valore b: {{ $b ?? null }} <br>
