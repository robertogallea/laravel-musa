<div id="footer">
    <h2>Copyright &copy; 2015-{{ date('Y') }}</h2>
</div>


