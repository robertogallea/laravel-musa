<footer id="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p class="copyright">&copy; 2014-{{ date('Y') }} {{ config('app.name') }}</p>
            </div>
        </div>
    </div>
</footer>
