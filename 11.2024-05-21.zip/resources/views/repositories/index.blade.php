@foreach($data['items'] as $repo)
    <li>{{ $repo['name'] }}</li>
@endforeach
