<h1>Divisione per zero!</h1>

<h2>{{ $exception->getMessage() }}</h2>

<h2>{{ $request->path() }}</h2>
