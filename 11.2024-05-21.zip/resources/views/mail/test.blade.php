Testo della mail
