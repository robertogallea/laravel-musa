Mail con allegato

<img src="{{ $message->embed('C:\Corso\public\img\me.jpg') }}">
