<?php

namespace App\Models\Observers;

class PostSaved
{
    public function __invoke()
    {

    }
}
